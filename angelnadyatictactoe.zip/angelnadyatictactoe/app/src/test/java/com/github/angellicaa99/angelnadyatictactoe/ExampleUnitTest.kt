package com.github.angellicaa99.angelnadyatictactoe

import org.junit.Assert
import org.junit.Test


class ExampleUnitTest {
    @Test
    @Throws(Exception::class)
    fun addition_isCorrect() {
        Assert.assertEquals(4, 2 + 2.toLong())
    }
}