package com.github.angellicaa99.angelnadyatictactoe

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class _4x4Activity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity__4x4)
        textViewPlayer1 = findViewById(R.id.text_view_p1)
        textViewPlayer2 = findViewById(R.id.text_view_p2)
        for (i in 0..3) {
            for (j in 0..3) {
                val buttonID = "button_$i$j"
                val resID = resources.getIdentifier(buttonID, "id", packageName)
                game_buttons[i][j] = findViewById(resID)
                game_buttons[i][j]?.setOnClickListener(this)
            }
        }
        val buttonReset = findViewById<Button>(R.id.button_reset)
        buttonReset.setOnClickListener { resetGame() }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onClick(v: View) {
        if ((v as Button).text.toString() != "") {
            return
        }
        if (numOfPlayers) {
            do {
                v.text = "X"
                if (checkForWin()) {
                    if (player1Turn) {
                        player1Wins()
                    } else {
                        player2Wins()
                    }
                }
                roundCount++
                player1Turn = !player1Turn
            } while (player1Turn)
            ComputerPlays()
            //                if(ComputerPlays()){
//                    resetBoard();
//}
//                else{
//                    player1Turn=true;
//                }
        } else {
            if (player1Turn) {
                v.text = "X"
            } else {
                v.text = "O"
            }
            roundCount++
        }
        if (checkForWin()) {
            if (player1Turn) {
                player1Wins()
            } else {
                player2Wins()
            }
        } else if (roundCount == 16) {
            draw()
        } else {
            player1Turn = !player1Turn
        }
    }

    private fun ComputerPlays() {
        val rand: Random
        rand = Random
        if (roundCount != 16) {
            var i: Int
            var j: Int
            //          String[][] field = new String[3][3];
            do {
                i = rand.nextInt(4)
                j = rand.nextInt(4)
            } while (game_buttons[i][j]!!.text.toString() != "")
            game_buttons[i][j]!!.text = "O"
            roundCount++
            //          field [i][j] = String.valueOf(game_buttons[i][j]);
//          return checkForWin();
        }
        //      return checkForWin();
    }

    private fun checkForWin(): Boolean {
        val field = Array(4) { arrayOfNulls<String>(4) }
        for (i in 0..3) {
            for (j in 0..3) {
                field[i][j] = game_buttons[i][j]!!.text.toString()
            }
        }
        for (i in 0..3) {
            if (field[i][0] == field[i][1] && field[i][0] == field[i][2] && field[i][0] == field[i][3] && field[i][0] != "") {
                return true
            }
        }
        for (i in 0..3) {
            if (field[0][i] == field[1][i] && field[0][i] == field[2][i] && field[0][i] == field[3][i] && field[0][i] != "") {
                return true
            }
        }
        if (field[0][0] == field[1][1] && field[0][0] == field[2][2] && field[0][0] == field[3][3] && field[0][0] != "") {
            return true
        }
        if (field[0][3] == field[1][2] && field[0][3] == field[2][1] && field[0][3] == field[3][0] && field[0][3] != "") {
            return true
        }
        if (field[0][2] == field[1][1] && field[0][2] == field[2][0] && field[0][2] != "") {
            return true
        }
        if (field[1][3] == field[2][2] && field[1][3] == field[3][1] && field[1][3] != "") {
            return true
        }
        if (field[1][0] == field[2][1] && field[1][0] == field[3][2] && field[1][0] != "") {
            return true
        }
        return if (field[0][1] == field[1][2] && field[0][1] == field[2][3] && field[0][1] != "") {
            true
        } else false
    }

    private fun player1Wins() {
        player1Points++
        Toast.makeText(this, "Player 1 wins!", Toast.LENGTH_SHORT).show()
        updatePointsText()
        resetBoard()
    }

    private fun player2Wins() {
        player2Points++
        Toast.makeText(this, "Player 2 wins!", Toast.LENGTH_SHORT).show()
        updatePointsText()
        resetBoard()
    }

    private fun draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show()
        resetBoard()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("roundCount", roundCount)
        outState.putInt("player1Points", player1Points)
        outState.putInt("player2Points", player2Points)
        outState.putBoolean("player1Turn", player1Turn)
    }

    public override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        roundCount = savedInstanceState.getInt("roundCount")
        player1Points = savedInstanceState.getInt("player1Points")
        player2Points = savedInstanceState.getInt("player2Points")
        player1Turn = savedInstanceState.getBoolean("player1Turn")
    }

    fun WelcomeActivity(view: View?) {
        onPause()
        val intent = Intent(this, WelcomePage::class.java)
        startActivity(intent)
    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {}

    companion object {
        private val game_buttons = Array(4) { arrayOfNulls<Button>(4) }
        private var player1Turn = true
        private var roundCount = 0
        private var player1Points = 0
        private var player2Points = 0
        @JvmField
        var numOfPlayers = false
        private var textViewPlayer1: TextView? = null
        private var textViewPlayer2: TextView? = null
        private fun updatePointsText() {
            if (numOfPlayers) {
                textViewPlayer1!!.text = "HUMAN: $player1Points"
                textViewPlayer2!!.text = "COMPUTER: $player2Points"
            } else {
                textViewPlayer1!!.text = "Player 1: $player1Points"
                textViewPlayer2!!.text = "Player 2: $player2Points"
            }
        }

        fun resetBoard() {
            for (i in 0..3) {
                for (j in 0..3) {
                    game_buttons[i][j]!!.text = ""
                }
            }
            roundCount = 0
            player1Turn = true
        }

        fun resetGame() {
            player1Points = 0
            player2Points = 0
            updatePointsText()
            resetBoard()
        }
    }
}