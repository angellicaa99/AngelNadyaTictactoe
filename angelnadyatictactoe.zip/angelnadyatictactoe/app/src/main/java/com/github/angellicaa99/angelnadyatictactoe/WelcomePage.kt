package com.github.angellicaa99.angelnadyatictactoe

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View

class WelcomePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome_page)
    }

    //    public void resumeGame(View view) {
//
//        Intent intent = new Intent(this, _3X3Activity.class);
//        startActivity(intent);
//        onResume();
//
//    }
    fun newGame(view: View?) {
        if (!SettingsActivity.settingsChange) {
            val intent = Intent(this, _3X3Activity::class.java)
            startActivity(intent)
        } else {
            if (SettingsActivity.Spinner1ItemSelected == "1 Player" && SettingsActivity.Spinner2ItemSelected == "3") {
                val intent = Intent(this, _3X3Activity::class.java)
                _3X3Activity.numOfPlayers = true
                startActivity(intent)
            } else if (SettingsActivity.Spinner2ItemSelected == "3" && SettingsActivity.Spinner1ItemSelected == "2 Players") {
                val intent = Intent(this, _3X3Activity::class.java)
                _3X3Activity.numOfPlayers = false
                startActivity(intent)
            } else if (SettingsActivity.Spinner2ItemSelected == "4" && SettingsActivity.Spinner1ItemSelected == "1 Player") {
                val intent = Intent(this, _4x4Activity::class.java)
                startActivity(intent)
                _4x4Activity.numOfPlayers = true
            } else if (SettingsActivity.Spinner2ItemSelected == "4" && SettingsActivity.Spinner1ItemSelected == "2 Players") {
                val intent = Intent(this, _4x4Activity::class.java)
                startActivity(intent)
                _4x4Activity.numOfPlayers = false
            } else if (SettingsActivity.Spinner2ItemSelected == "5" && SettingsActivity.Spinner1ItemSelected == "1 Player") {
                val intent = Intent(this, _5x5Activity::class.java)
                startActivity(intent)
                _5x5Activity.numOfPlayers = true
            } else {
                val intent = Intent(this, _5x5Activity::class.java)
                startActivity(intent)
            }
        }
    }

    fun settingsPage(view: View?) {
        val intent = Intent(this, SettingsActivity::class.java)
        startActivity(intent)
    }

    fun exitGame(view: View?) {
        finish()
        System.exit(0)
    }
}