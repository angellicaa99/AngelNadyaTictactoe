package com.github.angellicaa99.angelnadyatictactoe

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast

class SettingsActivity : AppCompatActivity() {
    private var spinner1: Spinner? = null
    private var spinner2: Spinner? = null
    private var btnSubmit: Button? = null
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        //addItemsOnSpinner2();
        addListenerOnButton()
        addListenerOnSpinnerItemSelection()
    }

    fun welcome_page(view: View?) {
        val intent = Intent(this, WelcomePage::class.java)
        startActivity(intent)
    }

    // add items into spinner dynamically
/*public void addItemsOnSpinner2() {

        spinner2 = findViewById(R.id.chooseBoardSizeSpinner);
        List<String> list = new ArrayList<String>();
        list.add("3");
        list.add("4");
        list.add("5");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);
    }
*/
    fun addListenerOnSpinnerItemSelection() {
        spinner1 = findViewById(R.id.choosePlayersSpinner)
        spinner1?.setOnItemSelectedListener(CustomOnItemSelectedListener())
    }

    // get the selected dropdown list value
    fun addListenerOnButton() {
        spinner1 = findViewById(R.id.choosePlayersSpinner)
        spinner2 = findViewById(R.id.chooseBoardSizeSpinner)
        btnSubmit = findViewById(R.id.btnSubmit)
        btnSubmit?.setOnClickListener(View.OnClickListener {
            Toast.makeText(this@SettingsActivity,
                    "OnClickListener : " +
                            "\nPlayers : " + spinner1?.getSelectedItem().toString() +
                            "\nBoard Size : " + spinner2?.getSelectedItem().toString(),
                    Toast.LENGTH_SHORT).show()
            Spinner1ItemSelected = "" + spinner1?.getSelectedItem().toString()
            Spinner2ItemSelected = "" + spinner2?.getSelectedItem().toString()
            settingsChange = true
            welcome_page2()
        })
    }

    fun welcome_page2() {
        val intent = Intent(this, WelcomePage::class.java)
        startActivity(intent)
    }

    companion object {
        @JvmField
        var Spinner1ItemSelected: String? = null
        @JvmField
        var Spinner2ItemSelected: String? = null
        @JvmField
        var settingsChange = false
    }
}